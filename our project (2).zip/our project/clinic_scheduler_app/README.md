# Clinic Scheduling Optimizer App

This Streamlit app demonstrates the project as an interactive scheduling dashboard.

It uses:
- `DOCTORS.csv`
- `tasks.csv`
- Greedy scheduling
- SA-only scheduling
- Hybrid scheduling
- Optional Gemini-guided limited repair

## Run

From this folder:

```powershell
pip install -r requirements.txt
streamlit run app.py
```

The default CSV paths point to:

```text
C:\Users\lamad\our project\DOCTORS.csv
C:\Users\lamad\our project\tasks.csv
```

You can change them in the sidebar.
