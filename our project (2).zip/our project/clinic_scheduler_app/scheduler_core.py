from __future__ import annotations

import json
import math
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


SLOTS_PER_DAY = 36
PRIORITY_MAP = {"EMERGENCY": 4, "URGENT": 3, "REGULAR": 2, "LOW": 1}
SPECIALTIES = [
    "Orthopedics",
    "Allergy",
    "Urology",
    "Women_Health",
    "Motology",
    "Neurology",
    "Diabetes",
    "Dermatology",
    "Ophthalmology",
    "Plastic_Surgery",
    "Hepatology",
    "ENT",
    "EMG",
    "Ultrasound",
]


@dataclass(frozen=True)
class Doctor:
    doctor_id: int
    doctor_name: str
    specialty: str
    start_slot: int
    end_slot: int


@dataclass(frozen=True)
class Task:
    task_id: str
    patient_id: int
    visit_type: str
    priority: int
    duration_slots: int
    preferred_doctor_id: Optional[int]
    preferred_day: Optional[int]
    deadline_day: Optional[int]
    preferred_start_slot: Optional[int]
    preferred_end_slot: Optional[int]


@dataclass(frozen=True)
class Assignment:
    task_id: str
    doctor_id: int
    day: int
    start_slot: int
    duration_slots: int

    @property
    def end_slot(self) -> int:
        return self.start_slot + self.duration_slots


class ScheduleState:
    def __init__(self, doctors: Dict[int, Doctor], horizon_days: int, slots_per_day: int):
        self.doctors = doctors
        self.horizon_days = horizon_days
        self.slots_per_day = slots_per_day
        self.busy = {
            did: np.zeros((horizon_days + 1, slots_per_day), dtype=bool)
            for did in doctors.keys()
        }
        self.assignments: Dict[str, Assignment] = {}

    def is_doctor_working(self, doctor_id: int, day: int, start_slot: int, duration: int) -> bool:
        if doctor_id not in self.doctors or not (0 <= day <= self.horizon_days):
            return False
        if not (0 <= start_slot < self.slots_per_day):
            return False
        end_slot = start_slot + duration
        if end_slot > self.slots_per_day:
            return False
        doctor = self.doctors[doctor_id]
        return start_slot >= doctor.start_slot and end_slot <= doctor.end_slot

    def is_free(self, doctor_id: int, day: int, start_slot: int, duration: int) -> bool:
        end_slot = start_slot + duration
        return not self.busy[doctor_id][day, start_slot:end_slot].any()

    def can_place(self, assignment: Assignment) -> bool:
        return (
            assignment.task_id not in self.assignments
            and self.is_doctor_working(
                assignment.doctor_id,
                assignment.day,
                assignment.start_slot,
                assignment.duration_slots,
            )
            and self.is_free(
                assignment.doctor_id,
                assignment.day,
                assignment.start_slot,
                assignment.duration_slots,
            )
        )

    def place(self, assignment: Assignment) -> bool:
        if not self.can_place(assignment):
            return False
        self.assignments[assignment.task_id] = assignment
        self.busy[assignment.doctor_id][
            assignment.day, assignment.start_slot : assignment.end_slot
        ] = True
        return True

    def remove(self, task_id: str) -> bool:
        assignment = self.assignments.get(task_id)
        if assignment is None:
            return False
        self.busy[assignment.doctor_id][
            assignment.day, assignment.start_slot : assignment.end_slot
        ] = False
        del self.assignments[task_id]
        return True

    def scheduled_count(self) -> int:
        return len(self.assignments)


def _optional_int(value) -> Optional[int]:
    if pd.isna(value) or str(value).strip() == "":
        return None
    return int(value)


def load_data(doctors_path: str | Path, tasks_path: str | Path) -> Tuple[Dict[int, Doctor], Dict[str, Task], pd.DataFrame, pd.DataFrame]:
    doctors_df = pd.read_csv(doctors_path)
    tasks_df = pd.read_csv(tasks_path)

    doctors: Dict[int, Doctor] = {}
    for _, row in doctors_df.iterrows():
        doctor = Doctor(
            doctor_id=int(row["doctor_id"]),
            doctor_name=str(row["doctor_name"]),
            specialty=str(row["specialty"]),
            start_slot=int(row["start_slot"]),
            end_slot=int(row["end_slot"]),
        )
        doctors[doctor.doctor_id] = doctor

    tasks: Dict[str, Task] = {}
    for _, row in tasks_df.iterrows():
        priority_str = str(row["priority"]).upper().strip()
        priority = PRIORITY_MAP.get(priority_str, int(row["priority"]) if str(row["priority"]).isdigit() else 2)
        task = Task(
            task_id=str(row["task_id"]),
            patient_id=int(row["patient_id"]),
            visit_type=str(row["visit_type"]),
            priority=priority,
            duration_slots=int(row["duration_slots"]),
            preferred_doctor_id=_optional_int(row.get("preferred_doctor_id", np.nan)),
            preferred_day=_optional_int(row.get("preferred_day", np.nan)),
            deadline_day=_optional_int(row.get("deadline_day", np.nan)),
            preferred_start_slot=_optional_int(row.get("preferred_start_slot", np.nan)),
            preferred_end_slot=_optional_int(row.get("preferred_end_slot", np.nan)),
        )
        tasks[task.task_id] = task

    return doctors, tasks, doctors_df, tasks_df


def compute_horizon_days(tasks: Dict[str, Task], default_days: int = 7) -> int:
    max_day = 0
    for task in tasks.values():
        if task.deadline_day is not None:
            max_day = max(max_day, task.deadline_day)
        if task.preferred_day is not None:
            max_day = max(max_day, task.preferred_day)
    return int(max_day if max_day > 0 else default_days)


def is_within_any_window(task_id: str, day: int, start_slot: int, duration: int, tasks: Dict[str, Task]) -> bool:
    task = tasks.get(task_id)
    if task is None:
        return False
    if task.preferred_day is None or task.preferred_start_slot is None or task.preferred_end_slot is None:
        return False
    end_slot = start_slot + duration
    return day == task.preferred_day and start_slot >= task.preferred_start_slot and end_slot <= task.preferred_end_slot


def assign_specialty_to_task(patient_id: int, preferred_doctor_id, doctors: Dict[int, Doctor]) -> str:
    if preferred_doctor_id is not None and preferred_doctor_id in doctors:
        return doctors[preferred_doctor_id].specialty
    return SPECIALTIES[int(patient_id) % len(SPECIALTIES)]


def candidate_doctors_for_task(task: Task, doctors: Dict[int, Doctor]) -> List[int]:
    required_spec = assign_specialty_to_task(task.patient_id, task.preferred_doctor_id, doctors)
    candidates = [did for did, doctor in doctors.items() if doctor.specialty == required_spec]
    if not candidates:
        candidates = list(doctors.keys())
    if task.preferred_doctor_id in candidates:
        candidates = [task.preferred_doctor_id] + [did for did in candidates if did != task.preferred_doctor_id]
    return candidates


def clone_state(state: ScheduleState) -> ScheduleState:
    cloned = ScheduleState(state.doctors, state.horizon_days, state.slots_per_day)
    for assignment in state.assignments.values():
        cloned.place(assignment)
    return cloned


def greedy_schedule(doctors: Dict[int, Doctor], tasks: Dict[str, Task], horizon_days: int, slots_per_day: int) -> ScheduleState:
    state = ScheduleState(doctors, horizon_days, slots_per_day)
    sorted_tasks = sorted(tasks.values(), key=lambda task: (-task.priority, task.duration_slots))

    for task in sorted_tasks:
        day_order = list(range(1, horizon_days + 1))
        if task.preferred_day is not None and 1 <= task.preferred_day <= horizon_days:
            day_order = [task.preferred_day] + [day for day in day_order if day != task.preferred_day]

        placed = False
        for day in day_order:
            for doctor_id in candidate_doctors_for_task(task, doctors):
                doctor = doctors[doctor_id]
                for start in range(doctor.start_slot, doctor.end_slot - task.duration_slots + 1):
                    if state.place(Assignment(task.task_id, doctor_id, day, start, task.duration_slots)):
                        placed = True
                        break
                if placed:
                    break
            if placed:
                break

    return state


def random_feasible_schedule(
    doctors: Dict[int, Doctor],
    tasks: Dict[str, Task],
    horizon_days: int,
    slots_per_day: int,
    seed: int = 1,
    max_tries_per_task: int = 500,
) -> ScheduleState:
    random.seed(seed)
    state = ScheduleState(doctors, horizon_days, slots_per_day)
    task_list = list(tasks.values())
    random.shuffle(task_list)

    for task in task_list:
        candidates = candidate_doctors_for_task(task, doctors)
        random.shuffle(candidates)
        placed = False

        for _ in range(max_tries_per_task):
            doctor_id = random.choice(candidates)
            doctor = doctors[doctor_id]
            day = random.randint(1, horizon_days)
            start = random.randint(doctor.start_slot, doctor.end_slot - task.duration_slots)
            if state.place(Assignment(task.task_id, doctor_id, day, start, task.duration_slots)):
                placed = True
                break

        if not placed:
            for day in range(1, horizon_days + 1):
                for doctor_id in candidates:
                    doctor = doctors[doctor_id]
                    for start in range(doctor.start_slot, doctor.end_slot - task.duration_slots + 1):
                        if state.place(Assignment(task.task_id, doctor_id, day, start, task.duration_slots)):
                            placed = True
                            break
                    if placed:
                        break
                if placed:
                    break

    return state


def schedule_score(
    state: ScheduleState,
    tasks: Dict[str, Task],
    w_scheduled: float = 100.0,
    w_priority: float = 20.0,
    reward_in_window: float = 20.0,
    penalty_not_in_window: float = 10.0,
    delay_weight: float = 50.0,
) -> float:
    score = 0.0
    for task_id, assignment in state.assignments.items():
        task = tasks[task_id]
        score += w_scheduled
        score += w_priority * (task.priority ** 2)
        has_window = task.preferred_day is not None and task.preferred_start_slot is not None and task.preferred_end_slot is not None
        if has_window:
            score += reward_in_window if is_within_any_window(task_id, assignment.day, assignment.start_slot, assignment.duration_slots, tasks) else -penalty_not_in_window
        if task.deadline_day is not None and assignment.day > task.deadline_day:
            score -= delay_weight * (assignment.day - task.deadline_day) * task.priority
    return score


def schedule_metrics(state: ScheduleState, tasks: Dict[str, Task]) -> Dict[str, float]:
    scheduled = state.scheduled_count()
    in_window = 0
    has_window = 0
    late_count = 0
    late_days_sum = 0

    for task_id, assignment in state.assignments.items():
        task = tasks[task_id]
        if task.preferred_day is not None and task.preferred_start_slot is not None and task.preferred_end_slot is not None:
            has_window += 1
            if is_within_any_window(task_id, assignment.day, assignment.start_slot, assignment.duration_slots, tasks):
                in_window += 1
        if task.deadline_day is not None and assignment.day > task.deadline_day:
            late_count += 1
            late_days_sum += assignment.day - task.deadline_day

    return {
        "scheduled": scheduled,
        "has_window": has_window,
        "in_window": in_window,
        "window_hit_rate": in_window / has_window if has_window else 0.0,
        "late_count": late_count,
        "late_days_sum": late_days_sum,
    }


def get_late_task_ids(state: ScheduleState, tasks: Dict[str, Task]) -> List[str]:
    return [
        task_id
        for task_id, assignment in state.assignments.items()
        if tasks[task_id].deadline_day is not None and assignment.day > tasks[task_id].deadline_day
    ]


def try_relocate_earlier(state: ScheduleState, task_id: str, tasks: Dict[str, Task], max_tries: int = 200) -> Optional[Assignment]:
    task = tasks[task_id]
    current = state.assignments[task_id]
    doctor = state.doctors[current.doctor_id]
    state.remove(task_id)

    day_candidates: List[int] = []
    if task.deadline_day is not None:
        day_candidates.extend(range(1, min(task.deadline_day, state.horizon_days) + 1))
    day_candidates.extend(range(1, current.day))
    day_candidates = list(dict.fromkeys(day_candidates))

    if task.preferred_day in day_candidates and task.preferred_start_slot is not None and task.preferred_end_slot is not None:
        for start in range(task.preferred_start_slot, task.preferred_end_slot - task.duration_slots + 1):
            assignment = Assignment(task_id, current.doctor_id, task.preferred_day, start, task.duration_slots)
            if state.place(assignment):
                return assignment

    candidates = [(day, start) for day in day_candidates for start in range(doctor.start_slot, doctor.end_slot - task.duration_slots + 1)]
    random.shuffle(candidates)
    for day, start in candidates[:max_tries]:
        assignment = Assignment(task_id, current.doctor_id, day, start, task.duration_slots)
        if state.place(assignment):
            return assignment

    state.place(current)
    return None


def try_move_to_window(state: ScheduleState, task_id: str, tasks: Dict[str, Task], max_tries: int = 200) -> Optional[Assignment]:
    task = tasks[task_id]
    current = state.assignments[task_id]
    if task.preferred_day is None or task.preferred_start_slot is None or task.preferred_end_slot is None:
        return None
    if is_within_any_window(task_id, current.day, current.start_slot, current.duration_slots, tasks):
        return None

    state.remove(task_id)
    doctors_to_try = candidate_doctors_for_task(task, state.doctors)
    if current.doctor_id in doctors_to_try:
        doctors_to_try = [current.doctor_id] + [did for did in doctors_to_try if did != current.doctor_id]

    tries = 0
    for doctor_id in doctors_to_try:
        for start in range(task.preferred_start_slot, task.preferred_end_slot - task.duration_slots + 1):
            assignment = Assignment(task_id, doctor_id, task.preferred_day, start, task.duration_slots)
            if state.place(assignment):
                return assignment
            tries += 1
            if tries >= max_tries:
                state.place(current)
                return None

    state.place(current)
    return None


def simulated_annealing_improve(
    state0: ScheduleState,
    tasks: Dict[str, Task],
    iters: int = 800,
    t0: float = 50.0,
    alpha: float = 0.995,
    focus_late_prob: float = 0.5,
    seed: int = 42,
) -> Tuple[ScheduleState, float]:
    random.seed(seed)
    state = clone_state(state0)
    best = clone_state(state)
    cur_score = schedule_score(state, tasks)
    best_score = cur_score
    temp = t0

    for _ in range(1, iters + 1):
        late_tasks = get_late_task_ids(state, tasks)
        if late_tasks and random.random() < focus_late_prob:
            task_id = random.choice(late_tasks)
            old_assignment = state.assignments[task_id]
            new_assignment = try_relocate_earlier(state, task_id, tasks, max_tries=250)
        else:
            task_id = random.choice(list(state.assignments.keys()))
            old_assignment = state.assignments[task_id]
            new_assignment = try_move_to_window(state, task_id, tasks, max_tries=250)
            if new_assignment is None:
                new_assignment = try_relocate_earlier(state, task_id, tasks, max_tries=250)

        if new_assignment is None or new_assignment == old_assignment:
            temp *= alpha
            continue

        new_score = schedule_score(state, tasks)
        delta = new_score - cur_score
        if delta >= 0 or random.random() < math.exp(delta / max(temp, 1e-9)):
            cur_score = new_score
            if cur_score > best_score:
                best = clone_state(state)
                best_score = cur_score
        else:
            state.remove(task_id)
            state.place(old_assignment)
        temp *= alpha

    return best, best_score


def schedule_to_dataframe(state: ScheduleState, tasks: Dict[str, Task], doctors: Dict[int, Doctor]) -> pd.DataFrame:
    rows = []
    for task_id, assignment in state.assignments.items():
        task = tasks[task_id]
        doctor = doctors[assignment.doctor_id]
        is_late = task.deadline_day is not None and assignment.day > task.deadline_day
        rows.append(
            {
                "task_id": task_id,
                "patient_id": task.patient_id,
                "doctor_id": assignment.doctor_id,
                "doctor_name": doctor.doctor_name,
                "specialty": doctor.specialty,
                "day": assignment.day,
                "start_slot": assignment.start_slot,
                "end_slot": assignment.end_slot,
                "duration_slots": assignment.duration_slots,
                "priority": task.priority,
                "visit_type": task.visit_type,
                "deadline_day": task.deadline_day,
                "preferred_day": task.preferred_day,
                "is_late": is_late,
                "days_late": assignment.day - task.deadline_day if is_late else 0,
                "in_preferred_window": is_within_any_window(task_id, assignment.day, assignment.start_slot, assignment.duration_slots, tasks),
            }
        )
    return pd.DataFrame(rows).sort_values(["day", "doctor_id", "start_slot"]).reset_index(drop=True)


def run_baselines(
    doctors_path: str | Path,
    tasks_path: str | Path,
    sa_iters: int = 800,
    random_seed: int = 1,
    hybrid_seed: int = 42,
) -> Dict[str, object]:
    doctors, tasks, doctors_df, tasks_df = load_data(doctors_path, tasks_path)
    horizon_days = compute_horizon_days(tasks, default_days=7)
    greedy_state = greedy_schedule(doctors, tasks, horizon_days, SLOTS_PER_DAY)
    random_state = random_feasible_schedule(doctors, tasks, horizon_days, SLOTS_PER_DAY, seed=random_seed)
    sa_state, sa_score = simulated_annealing_improve(random_state, tasks, iters=sa_iters, seed=random_seed)
    hybrid_state, hybrid_score = simulated_annealing_improve(greedy_state, tasks, iters=sa_iters, seed=hybrid_seed)

    states = {"Greedy": greedy_state, "SA-only": sa_state, "Hybrid": hybrid_state}
    rows = []
    for method, state in states.items():
        rows.append({"Method": method, "Score": schedule_score(state, tasks), **schedule_metrics(state, tasks)})

    return {
        "doctors": doctors,
        "tasks": tasks,
        "doctors_df": doctors_df,
        "tasks_df": tasks_df,
        "horizon_days": horizon_days,
        "states": states,
        "comparison": pd.DataFrame(rows),
        "best_method": max(rows, key=lambda row: row["Score"])["Method"],
    }


def task_problem_score(task_id: str, state: ScheduleState, tasks: Dict[str, Task]) -> float:
    if task_id not in state.assignments:
        return 10000.0
    assignment = state.assignments[task_id]
    task = tasks[task_id]
    score = task.priority * 3 + task.duration_slots
    if task.deadline_day is not None and assignment.day > task.deadline_day:
        score += 150 + 50 * (assignment.day - task.deadline_day) * max(1, task.priority)
    has_window = task.preferred_day is not None and task.preferred_start_slot is not None and task.preferred_end_slot is not None
    if has_window and not is_within_any_window(task_id, assignment.day, assignment.start_slot, assignment.duration_slots, tasks):
        score += 10 * max(1, task.priority) + 20
    if task.preferred_day is not None and assignment.day != task.preferred_day:
        score += abs(assignment.day - task.preferred_day) * 2
    return float(score)


def find_problematic_tasks(state: ScheduleState, tasks: Dict[str, Task], doctors: Dict[int, Doctor], top_n: int = 40) -> pd.DataFrame:
    rows = []
    for task_id, assignment in state.assignments.items():
        task = tasks[task_id]
        doctor = doctors[assignment.doctor_id]
        days_late = assignment.day - task.deadline_day if task.deadline_day is not None and assignment.day > task.deadline_day else 0
        in_window = is_within_any_window(task_id, assignment.day, assignment.start_slot, assignment.duration_slots, tasks)
        rows.append(
            {
                "task_id": task_id,
                "priority": task.priority,
                "duration_slots": task.duration_slots,
                "deadline_day": task.deadline_day,
                "preferred_day": task.preferred_day,
                "preferred_start_slot": task.preferred_start_slot,
                "preferred_end_slot": task.preferred_end_slot,
                "current_day": assignment.day,
                "current_start": assignment.start_slot,
                "current_end": assignment.end_slot,
                "days_late": days_late,
                "in_preferred_window": in_window,
                "specialty": doctor.specialty,
                "problem_score": task_problem_score(task_id, state, tasks),
            }
        )
    return pd.DataFrame(rows).sort_values("problem_score", ascending=False).head(top_n).reset_index(drop=True)


def extract_json_from_text(text: str) -> dict:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        return json.loads(text[start : end + 1])


def ask_gemini_for_repair_tasks(candidate_df: pd.DataFrame, api_key: str, model: str = "gemini-2.5-flash", max_tasks: int = 10) -> dict:
    lines = []
    for _, row in candidate_df.iterrows():
        lines.append(
            f"- task_id={row['task_id']}, priority={row['priority']}, duration={row['duration_slots']}, "
            f"current_day={row['current_day']}, current_slots={row['current_start']}-{row['current_end']}, "
            f"deadline_day={row['deadline_day']}, days_late={row['days_late']}, "
            f"preferred_window=day {row['preferred_day']} slots {row['preferred_start_slot']}-{row['preferred_end_slot']}, "
            f"in_preferred_window={row['in_preferred_window']}, specialty={row['specialty']}"
        )
    prompt = f"""
Choose at most {max_tasks} task IDs that are most likely to improve a medical scheduling objective if repaired.
Prefer high-priority tasks, late tasks, and tasks outside preferred windows.
You are intentionally not given the numeric problem_score; reason from the raw scheduling details only.

Candidate tasks:
{chr(10).join(lines)}

Return JSON only:
{{"repair_task_ids": ["task_id"], "reason": "short reason"}}
""".strip()
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Gemini API HTTP error {exc.code}: {body}") from exc
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    return extract_json_from_text(text)


def selected_tasks_score_contribution(state: ScheduleState, task_ids: List[str], tasks: Dict[str, Task]) -> float:
    temp = ScheduleState(state.doctors, state.horizon_days, state.slots_per_day)
    for task_id in task_ids:
        assignment = state.assignments.get(task_id)
        if assignment is not None:
            temp.place(assignment)
    return schedule_score(temp, tasks)


def candidate_days_for_repair(task: Task, current_day: int, horizon_days: int) -> List[int]:
    days: List[int] = []
    if task.preferred_day is not None:
        days.append(task.preferred_day)
    if task.deadline_day is not None:
        days.extend(range(1, min(task.deadline_day, horizon_days) + 1))
    days.extend(range(1, current_day + 1))
    days.extend(range(1, horizon_days + 1))
    return [day for day in dict.fromkeys(days) if 1 <= day <= horizon_days]


def try_direct_best_relocation(state: ScheduleState, task_id: str, tasks: Dict[str, Task], doctors: Dict[int, Doctor]) -> Tuple[bool, float]:
    if task_id not in state.assignments:
        return False, schedule_score(state, tasks)

    old_score = schedule_score(state, tasks)
    old_assignment = state.assignments[task_id]
    task = tasks[task_id]
    best_assignment = None
    best_score = old_score

    state.remove(task_id)
    for day in candidate_days_for_repair(task, old_assignment.day, state.horizon_days):
        for doctor_id in candidate_doctors_for_task(task, doctors):
            doctor = doctors[doctor_id]
            starts = list(range(doctor.start_slot, doctor.end_slot - task.duration_slots + 1))
            if day == task.preferred_day and task.preferred_start_slot is not None and task.preferred_end_slot is not None:
                preferred_starts = list(range(task.preferred_start_slot, task.preferred_end_slot - task.duration_slots + 1))
                starts = preferred_starts + [start for start in starts if start not in preferred_starts]
            for start in starts:
                assignment = Assignment(task_id, doctor_id, day, start, task.duration_slots)
                if state.place(assignment):
                    score = schedule_score(state, tasks)
                    state.remove(task_id)
                    if score > best_score:
                        best_score = score
                        best_assignment = assignment

    if best_assignment is not None:
        state.place(best_assignment)
        return True, best_score - old_score

    state.place(old_assignment)
    return False, 0.0


def run_ai_guided_repair(base_state: ScheduleState, repair_task_ids: List[str], tasks: Dict[str, Task], doctors: Dict[int, Doctor]) -> Tuple[ScheduleState, pd.DataFrame]:
    repaired = clone_state(base_state)
    rows = []
    for task_id in repair_task_ids:
        before = schedule_score(repaired, tasks)
        improved, delta = try_direct_best_relocation(repaired, task_id, tasks, doctors)
        after = schedule_score(repaired, tasks)
        rows.append({"task_id": task_id, "improved": improved, "score_delta": delta, "score_before": before, "score_after": after})
    return repaired, pd.DataFrame(rows)


def evaluate_ai_cases_on_methods(method_states: Dict[str, ScheduleState], repair_task_ids: List[str], tasks: Dict[str, Task], doctors: Dict[int, Doctor]) -> Tuple[pd.DataFrame, Dict[str, pd.DataFrame], Dict[str, ScheduleState]]:
    rows = []
    details = {}
    repaired_states = {}
    for method, state in method_states.items():
        valid_ids = [task_id for task_id in repair_task_ids if task_id in state.assignments]
        before_score = schedule_score(state, tasks)
        before_selected = selected_tasks_score_contribution(state, valid_ids, tasks)
        before_metrics = schedule_metrics(state, tasks)
        repaired, report = run_ai_guided_repair(state, valid_ids, tasks, doctors)
        after_score = schedule_score(repaired, tasks)
        after_selected = selected_tasks_score_contribution(repaired, valid_ids, tasks)
        after_metrics = schedule_metrics(repaired, tasks)
        rows.append(
            {
                "Method": method,
                "Gemini cases tested": len(valid_ids),
                "Accepted repairs": int(report["improved"].sum()) if len(report) else 0,
                "Global score before": before_score,
                "Global score after": after_score,
                "Global score delta": after_score - before_score,
                "Selected cases score before": before_selected,
                "Selected cases score after": after_selected,
                "Selected cases score delta": after_selected - before_selected,
                "Late count before": before_metrics["late_count"],
                "Late count after": after_metrics["late_count"],
                "Late count delta": after_metrics["late_count"] - before_metrics["late_count"],
            }
        )
        details[method] = report
        repaired_states[method] = repaired
    return pd.DataFrame(rows), details, repaired_states
