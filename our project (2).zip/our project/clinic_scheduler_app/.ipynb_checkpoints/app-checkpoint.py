from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from scheduler_core import (
    ask_gemini_for_repair_tasks,
    find_problematic_tasks,
    PRIORITY_MAP,
    run_baselines,
    run_ai_guided_repair,
    schedule_metrics,
    schedule_score,
    schedule_to_dataframe,
    selected_tasks_score_contribution,
)


PROJECT_DIR = Path(r"C:\Users\lamad\our project")
DEFAULT_DOCTORS = PROJECT_DIR / "DOCTORS.csv"
DEFAULT_TASKS = PROJECT_DIR / "tasks.csv"


st.set_page_config(page_title="Clinic Scheduling Optimizer", layout="wide")

st.title("Clinic Scheduling Optimizer")
st.caption("Greedy vs SA-only vs Hybrid, with optional Gemini-guided limited repair.")


with st.sidebar:
    st.header("Data")
    doctors_path = st.text_input("Doctors CSV", str(DEFAULT_DOCTORS))
    tasks_path = st.text_input("Tasks CSV", str(DEFAULT_TASKS))
    st.header("Run settings")
    sa_iters = st.slider("SA iterations", min_value=100, max_value=3000, value=800, step=100)
    candidate_pool = st.slider("AI candidate pool", min_value=5, max_value=50, value=20, step=5)
    repair_count = st.slider("AI repair cases", min_value=1, max_value=20, value=10, step=1)
    use_gemini = st.toggle("Use real Gemini API", value=False)
    gemini_key = ""
    if use_gemini:
        gemini_key = st.text_input("Gemini API key", type="password")


@st.cache_data(show_spinner=False)
def run_cached(doctors_path_value: str, tasks_path_value: str, iters: int):
    return run_baselines(doctors_path_value, tasks_path_value, sa_iters=iters)


def next_task_id(tasks_df: pd.DataFrame) -> str:
    numeric_ids = (
        tasks_df["task_id"]
        .astype(str)
        .str.extract(r"(\d+)$")[0]
        .dropna()
        .astype(int)
    )
    next_number = int(numeric_ids.max()) + 1 if len(numeric_ids) else len(tasks_df) + 1
    return f"T{next_number:06d}"


def next_patient_id(tasks_df: pd.DataFrame) -> int:
    if "patient_id" not in tasks_df.columns or len(tasks_df) == 0:
        return 1
    return int(pd.to_numeric(tasks_df["patient_id"], errors="coerce").max()) + 1


def append_task_to_csv(tasks_path_value: str, new_task: dict) -> None:
    path = Path(tasks_path_value)
    tasks_df = pd.read_csv(path)
    updated = pd.concat([tasks_df, pd.DataFrame([new_task])], ignore_index=True)
    updated.to_csv(path, index=False)


if not Path(doctors_path).exists() or not Path(tasks_path).exists():
    st.error("One or both CSV paths do not exist. Check the paths in the sidebar.")
    st.stop()

if st.sidebar.button("Run Scheduling", type="primary") or "results" not in st.session_state:
    with st.spinner("Running Greedy, SA-only, and Hybrid..."):
        st.session_state.results = run_cached(doctors_path, tasks_path, sa_iters)

results = st.session_state.results
comparison = results["comparison"]
doctors = results["doctors"]
tasks = results["tasks"]
states = results["states"]

new_task_tab, overview_tab, compare_tab, schedule_tab, ai_tab = st.tabs(
    ["New Patient Task", "Data Overview", "Algorithm Comparison", "Schedule View", "AI Limited Repair"]
)

with new_task_tab:
    st.subheader("Add a new patient task")
    st.write(
        "Fill this form to add a new task directly into the active tasks CSV. "
        "After saving, run scheduling again so the new request enters the optimization."
    )

    current_tasks_df = pd.read_csv(tasks_path)
    current_doctors_df = pd.read_csv(doctors_path)
    generated_task_id = next_task_id(current_tasks_df)
    generated_patient_id = next_patient_id(current_tasks_df)

    st.info(f"Next task ID will be `{generated_task_id}`.")

    doctor_options = ["No preferred doctor"] + [
        f"{int(row.doctor_id)} - {row.doctor_name} ({row.specialty})"
        for row in current_doctors_df.itertuples(index=False)
    ]

    with st.form("new_patient_task_form", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        patient_id = c1.number_input("Patient ID", min_value=1, value=generated_patient_id, step=1)
        visit_type = c2.selectbox(
            "Visit type",
            ["CONSULTATION", "FOLLOW_UP", "TREATMENT", "CHECKUP", "PROCEDURE"],
        )
        priority = c3.selectbox("Priority", list(PRIORITY_MAP.keys()), index=2)

        c4, c5, c6 = st.columns(3)
        duration_slots = c4.number_input("Duration slots", min_value=1, max_value=12, value=3, step=1)
        preferred_doctor_choice = c5.selectbox("Preferred doctor", doctor_options)
        deadline_day = c6.number_input(
            "Deadline day",
            min_value=1,
            max_value=int(results["horizon_days"]) + 14,
            value=min(7, int(results["horizon_days"])),
            step=1,
        )

        st.caption("Preferred time window")
        c7, c8, c9 = st.columns(3)
        preferred_day = c7.number_input(
            "Preferred day",
            min_value=1,
            max_value=int(results["horizon_days"]) + 14,
            value=min(7, int(results["horizon_days"])),
            step=1,
        )
        preferred_start_slot = c8.number_input("Preferred start slot", min_value=0, max_value=35, value=9, step=1)
        preferred_end_slot = c9.number_input("Preferred end slot", min_value=1, max_value=36, value=18, step=1)

        submitted = st.form_submit_button("Add task to CSV", type="primary")

    if submitted:
        if preferred_end_slot <= preferred_start_slot:
            st.error("Preferred end slot must be greater than preferred start slot.")
        elif preferred_end_slot - preferred_start_slot < duration_slots:
            st.error("The preferred window must be long enough for the task duration.")
        else:
            preferred_doctor_id = ""
            if preferred_doctor_choice != "No preferred doctor":
                preferred_doctor_id = int(preferred_doctor_choice.split(" - ", 1)[0])

            new_task = {
                "task_id": generated_task_id,
                "patient_id": int(patient_id),
                "visit_type": visit_type,
                "priority": priority,
                "duration_slots": int(duration_slots),
                "preferred_doctor_id": preferred_doctor_id,
                "preferred_day": int(preferred_day),
                "deadline_day": int(deadline_day),
                "preferred_start_slot": int(preferred_start_slot),
                "preferred_end_slot": int(preferred_end_slot),
            }
            append_task_to_csv(tasks_path, new_task)
            run_cached.clear()
            for key in ["results", "ai_results", "ai_details", "repaired_states", "ai_selected_ids", "ai_reason"]:
                st.session_state.pop(key, None)
            st.success(f"Task {generated_task_id} was added to `{tasks_path}`.")
            st.rerun()

with overview_tab:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Doctors", len(doctors))
    c2.metric("Tasks", len(tasks))
    c3.metric("Horizon days", results["horizon_days"])
    c4.metric("Best baseline", results["best_method"])

    left, right = st.columns(2)
    with left:
        st.subheader("Tasks by visit type")
        st.bar_chart(results["tasks_df"]["visit_type"].value_counts())
    with right:
        st.subheader("Doctors by specialty")
        st.bar_chart(results["doctors_df"]["specialty"].value_counts())

    st.subheader("Task sample")
    st.dataframe(results["tasks_df"].head(50), use_container_width=True)

with compare_tab:
    st.subheader("Baseline Results")
    st.dataframe(comparison, use_container_width=True)

    score_df = comparison.set_index("Method")[["Score"]]
    late_df = comparison.set_index("Method")[["late_count"]]
    window_df = comparison.set_index("Method")[["window_hit_rate"]]

    a, b, c = st.columns(3)
    with a:
        st.caption("Objective Score")
        st.bar_chart(score_df)
    with b:
        st.caption("Late Tasks")
        st.bar_chart(late_df)
    with c:
        st.caption("Preferred Window Hit Rate")
        st.bar_chart(window_df)

    st.info(
        "The project conclusion is based on the objective score: Hybrid starts from Greedy and then improves the schedule with SA."
    )

with schedule_tab:
    method = st.selectbox("Choose schedule", list(states.keys()), index=list(states.keys()).index("Hybrid"))
    schedule_df = schedule_to_dataframe(states[method], tasks, doctors)

    c1, c2, c3 = st.columns(3)
    day_filter = c1.selectbox("Day", ["All"] + sorted(schedule_df["day"].unique().tolist()))
    specialty_filter = c2.selectbox("Specialty", ["All"] + sorted(schedule_df["specialty"].unique().tolist()))
    doctor_filter = c3.selectbox("Doctor", ["All"] + sorted(schedule_df["doctor_id"].unique().tolist()))

    filtered = schedule_df.copy()
    if day_filter != "All":
        filtered = filtered[filtered["day"] == day_filter]
    if specialty_filter != "All":
        filtered = filtered[filtered["specialty"] == specialty_filter]
    if doctor_filter != "All":
        filtered = filtered[filtered["doctor_id"] == doctor_filter]

    st.dataframe(filtered, use_container_width=True, height=520)
    st.download_button(
        "Download selected schedule CSV",
        filtered.to_csv(index=False).encode("utf-8"),
        file_name=f"{method.lower().replace('-', '_')}_schedule.csv",
        mime="text/csv",
    )

with ai_tab:
    st.subheader("Hybrid AI-guided repair")
    st.write(
        "The app first proves Hybrid is the best baseline, then tests whether AI-guided repair can improve the Hybrid schedule."
    )

    hybrid_state = states["Hybrid"]
    problematic_df = find_problematic_tasks(hybrid_state, tasks, doctors, top_n=candidate_pool)
    st.caption("Limited candidate pool")
    st.dataframe(problematic_df, use_container_width=True)

    def evaluate_hybrid_strategy(strategy_name: str, selected_ids: list[str]) -> tuple[dict, pd.DataFrame]:
        selected_ids = [task_id for task_id in selected_ids if task_id in hybrid_state.assignments]
        before_score = schedule_score(hybrid_state, tasks)
        before_metrics = schedule_metrics(hybrid_state, tasks)
        before_selected = selected_tasks_score_contribution(hybrid_state, selected_ids, tasks)

        repaired_state, repair_report = run_ai_guided_repair(hybrid_state, selected_ids, tasks, doctors)

        after_score = schedule_score(repaired_state, tasks)
        after_metrics = schedule_metrics(repaired_state, tasks)
        after_selected = selected_tasks_score_contribution(repaired_state, selected_ids, tasks)

        accepted_repairs = int(repair_report["improved"].sum()) if len(repair_report) else 0
        result = {
            "Strategy": strategy_name,
            "Cases tested": len(selected_ids),
            "Accepted repairs": accepted_repairs,
            "Hybrid score before": before_score,
            "Hybrid score after": after_score,
            "Hybrid score delta": after_score - before_score,
            "Selected cases score before": before_selected,
            "Selected cases score after": after_selected,
            "Selected cases score delta": after_selected - before_selected,
            "Late count before": before_metrics["late_count"],
            "Late count after": after_metrics["late_count"],
            "Late count delta": after_metrics["late_count"] - before_metrics["late_count"],
            "Window hit rate before": before_metrics["window_hit_rate"],
            "Window hit rate after": after_metrics["window_hit_rate"],
            "Window hit rate delta": after_metrics["window_hit_rate"] - before_metrics["window_hit_rate"],
        }
        result["Score delta per tested case"] = (
            result["Hybrid score delta"] / result["Cases tested"]
            if result["Cases tested"]
            else 0
        )
        return result, repair_report

    if st.button("Run Hybrid AI Repair Experiment"):
        selected_ids = problematic_df["task_id"].head(repair_count).tolist()
        ai_reason = "Fallback heuristic: selected the highest problem-score cases."

        if use_gemini and gemini_key.strip():
            try:
                with st.spinner("Calling Gemini for case selection..."):
                    plan = ask_gemini_for_repair_tasks(problematic_df, gemini_key.strip(), max_tasks=repair_count)
                selected_ids = [
                    task_id
                    for task_id in plan.get("repair_task_ids", [])
                    if task_id in problematic_df["task_id"].tolist()
                ][:repair_count]
                ai_reason = plan.get("reason", "Gemini selected the limited repair cases.")
            except Exception as exc:
                st.warning(f"Gemini failed, so fallback heuristic was used. Error: {exc}")

        selected_ids = selected_ids[:repair_count]
        st.session_state.ai_selected_ids = selected_ids
        st.session_state.ai_reason = ai_reason
        gemini_result, gemini_details = evaluate_hybrid_strategy("Gemini selected", selected_ids)

        candidate_ids = [task_id for task_id in problematic_df["task_id"].tolist() if task_id in hybrid_state.assignments]
        heuristic_ids = candidate_ids[: len(selected_ids)]
        all_ids = candidate_ids
        random_ids = (
            pd.Series(candidate_ids)
            .sample(n=min(len(selected_ids), len(candidate_ids)), random_state=7)
            .tolist()
            if candidate_ids
            else []
        )

        control_rows = [gemini_result]
        detail_tables = {"Gemini selected": gemini_details}
        for strategy_name, strategy_ids in [
            ("Heuristic top problem-score", heuristic_ids),
            ("Random from same pool", random_ids),
            ("Repair all limited problematic cases", all_ids),
        ]:
            result, details = evaluate_hybrid_strategy(strategy_name, strategy_ids)
            control_rows.append(result)
            detail_tables[strategy_name] = details

        st.session_state.ai_results = pd.DataFrame(control_rows)
        st.session_state.ai_details = detail_tables

    if "ai_results" in st.session_state:
        st.write("Selected task IDs:", st.session_state.ai_selected_ids)
        st.write("Reason:", st.session_state.ai_reason)
        st.dataframe(st.session_state.ai_results, use_container_width=True)

        x = st.session_state.ai_results.set_index("Strategy")
        left, mid, right, fourth = st.columns(4)
        with left:
            st.caption("Hybrid Score Improvement")
            st.bar_chart(x[["Hybrid score delta"]])
        with mid:
            st.caption("Selected Cases Score Improvement")
            st.bar_chart(x[["Selected cases score delta"]])
        with right:
            st.caption("Accepted Repairs")
            st.bar_chart(x[["Accepted repairs"]])
        with fourth:
            st.caption("Efficiency per Tested Case")
            st.bar_chart(x[["Score delta per tested case"]])

        st.info(
            "Main result: compare Hybrid before AI and Hybrid after Gemini-guided repair. "
            "Controls are included only to show whether Gemini selection is better or more efficient than simple alternatives."
        )

        detail_strategy = st.selectbox("Repair details for strategy", list(st.session_state.ai_details.keys()))
        st.dataframe(st.session_state.ai_details[detail_strategy], use_container_width=True)
